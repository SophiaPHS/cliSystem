<template>
	<view>
		这人很懒，什么也没写
	</view>
</template>

<script>
</script>

<style>
</style>