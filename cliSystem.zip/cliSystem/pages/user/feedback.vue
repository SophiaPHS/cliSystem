<template>
	<view class="container">
		<img src="../../static/iconfont_png/nulikaifazhong.png" alt="">
	</view>
</template>

<script>
	export default{
		
	}
</script>

<style lang="scss">
	.container {
		width: 100%;
		height: 100%;
		
		img{
			display: block;
			margin: 0 auto;
			margin-top: 50%;
			display: block;
			width: 300rpx;
			height: 300rpx;
		}
	}
</style>